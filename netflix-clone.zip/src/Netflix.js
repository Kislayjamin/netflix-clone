import React, { useState, useEffect } from 'react';
import './Films.css';
import { Link } from 'react-router-dom';
function Disney() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
  const fetchMovies = async () => {
  try {
  const apiKey = 'be5dbe26845f42388321ae8a91a8fa79';
  const response = await fetch(
  `https://api.themoviedb.org/3/discover/movie?api_key=${apiKey}&certification_country=India&sort_by=popularity.desc`
  );
  const data = await response.json();
  setMovies(data.results);
  } catch (error) {
  console.log(error);
  }
  };

    fetchMovies();
  }, []);
  return (
    <div className="container">
      <h1 className="title">Netflix Kids App</h1>
      <h2 className="subtitle">Movies:</h2>
      <div className="movies">
        {movies.length > 0 ? (
          movies.map(movie => (
            <div className="movie" key={movie.id}>
              <Link to="rfc" state={movie}>
                <h3 className="movie-title">{movie.title}</h3>
                <img
                  className="movie-poster"
                  src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                  alt={movie.title}
                />
                <p className="movie-description">{movie.overview.split("", 90)}</p>
              </Link>
            </div>
          ))
        ) : (
          <p>Loading movies...</p>
        )}
      </div>
    </div>
  );
}

export default Disney;
